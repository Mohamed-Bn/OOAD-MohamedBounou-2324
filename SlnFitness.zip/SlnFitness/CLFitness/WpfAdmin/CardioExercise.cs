﻿using CLFitness.WpfCustomer;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CLFitness.WpfAdmin
{
    public class CardioExercise : Exercise
    {
        // No specific fields for CardioExercise
    }
}